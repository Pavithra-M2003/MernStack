import React from "react";
import Counter from "./Counter";
import WithUseMemo from "./UseMemo";
import  UseCallback from "./UseCallback";
import CounterApp from "./CounterApp";

function App() {
  return (
    <div>
      <Counter />
      <WithUseMemo/>
      <UseCallback/>
      <CounterApp/>
    </div>
  );
}

export default App;
